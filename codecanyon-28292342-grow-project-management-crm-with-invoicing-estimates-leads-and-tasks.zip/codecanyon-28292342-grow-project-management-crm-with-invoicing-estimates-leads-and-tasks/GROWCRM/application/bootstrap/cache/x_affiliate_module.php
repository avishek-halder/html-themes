<?php return array (
  'providers' => 
  array (
    0 => 'Modules\\XAffiliate\\Providers\\XAffiliateServiceProvider',
  ),
  'eager' => 
  array (
    0 => 'Modules\\XAffiliate\\Providers\\XAffiliateServiceProvider',
  ),
  'deferred' => 
  array (
  ),
);