<?php return array (
  'providers' => 
  array (
    0 => 'Modules\\DesignSpecification\\Providers\\DesignSpecificationServiceProvider',
  ),
  'eager' => 
  array (
    0 => 'Modules\\DesignSpecification\\Providers\\DesignSpecificationServiceProvider',
  ),
  'deferred' => 
  array (
  ),
);