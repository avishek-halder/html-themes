<?php return array (
  'providers' => 
  array (
    0 => 'Modules\\Sample\\Providers\\SampleServiceProvider',
  ),
  'eager' => 
  array (
    0 => 'Modules\\Sample\\Providers\\SampleServiceProvider',
  ),
  'deferred' => 
  array (
  ),
);